import argparse
import numpy as np
import torch
from torchvision import datasets,transforms, models
from torch import nn, optim

from collections import OrderedDict
import time
import matplotlib.pyplot as plt
from PIL import Image
import matplotlib
import json





parser=argparse.ArgumentParser()

parser.add_argument( 'data_directory', actions='store',default='flowers',help='Set directory to load training data')

parser.add_argument('--save_dir', action='store', default='.',dest='save_dir', help='Sat directory to sace checkpoint')

parser.add_argument('--arch', action='store', default='vgg19', dest='arch', help='Choose architecture')

parser.add_argument('--learning_rate',action='store',default= 0.001, dest='learning_rate', help='Choose learning rate')

parser.add_argument('--hidden_units', action='store', default=15088, dest='hidden_units', help='choose hidden units')

parser.add_argument('--epochs', action='store', default=5, dest='epochs',help='Choose number of ephochs')

parser.add_argument('--gpu', action='store_true', default= False, dest='gpu', help='Use GPU for training set to true' )

parse_results=parser.parse_args()

data_dir=parse_results.data_directory
save_dir=parse_results.save_dir
arch=parse_results.arch
learning_rate=parse_results.learning_rate
hidden_units=int(parse_results.hidden_units)
epochs=int(parse_results.epochs)
gpu=parse_results.gpu

image_datasets, train_loader, valid_loader, test_loader = prepoc(data_dir)

initial_model= build_model(arch,hidden_units)
model, optimizer, criterion = train_model(initial_model, train_loader,valid_loader,learning_rate,epochs,gpu)

model.to('cpu')
model.class_to_idx=image_datasets['train_data'].class_to_idx
checkpoint={ 'input_size' : 25088,
            'output_size' : 102,
            'model': model,
            'state_dict': model.state_dict(),
            'optimizer_state_dict' : optimizer.state_dict,
            'criterion': criterion,
            'epochs' : epochs,
            'class_to_idx' : model.class_to_idx}

torch.save(checkpoint, save_dir +'checkpoint.pth')

if save_dir=='.':
    save_dir_name= 'current folder'
else:
    save_dir_name =save_dir + 'folder'

print(f' Checkpoint is saved to {save_dir_name}')
import argparse
import numpy as np
import torch
from torchvision import datasets,transforms, models
from torch import nn, optim

from collections import OrderedDict
import time
import matplotlib.pyplot as plt
from PIL import Image
import matplotlib
import json





parser=argparse.ArgumentParser()

parser.add_argument( 'data_directory', actions='store',default='flowers',help='Set directory to load training data')

parser.add_argument('--save_dir', action='store', default='.',dest='save_dir', help='Sat directory to sace checkpoint')

parser.add_argument('--arch', action='store', default='vgg19', dest='arch', help='Choose architecture')

parser.add_argument('--learning_rate',action='store',default= 0.001, dest='learning_rate', help='Choose learning rate')

parser.add_argument('--hidden_units', action='store', default=15088, dest='hidden_units', help='choose hidden units')

parser.add_argument('--epochs', action='store', default=5, dest='epochs',help='Choose number of ephochs')

parser.add_argument('--gpu', action='store_true', default= False, dest='gpu', help='Use GPU for training set to true' )

parse_results=parser.parse_args()

data_dir=parse_results.data_directory
save_dir=parse_results.save_dir
arch=parse_results.arch
learning_rate=parse_results.learning_rate
hidden_units=int(parse_results.hidden_units)
epochs=int(parse_results.epochs)
gpu=parse_results.gpu

image_datasets, train_loader, valid_loader, test_loader = prepoc(data_dir)

initial_model= build_model(arch,hidden_units)
model, optimizer, criterion = train_model(initial_model, train_loader,valid_loader,learning_rate,epochs,gpu)

model.to('cpu')
model.class_to_idx=image_datasets['train_data'].class_to_idx
checkpoint={ 'input_size' : 25088,
            'output_size' : 102,
            'model': model,
            'state_dict': model.state_dict(),
            'optimizer_state_dict' : optimizer.state_dict,
            'criterion': criterion,
            'epochs' : epochs,
            'class_to_idx' : model.class_to_idx}

torch.save(checkpoint, save_dir +'checkpoint.pth')

if save_dir=='.':
    save_dir_name= 'current folder'
else:
    save_dir_name =save_dir + 'folder'

print(f' Checkpoint is saved to {save_dir_name}')

                    
              
